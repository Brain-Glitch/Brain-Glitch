"""Declares this module as a package"""

# api/__init__.py

# This file can be empty or contain initialization code for the package

# from dotenv import load_dotenv

# load_dotenv()
