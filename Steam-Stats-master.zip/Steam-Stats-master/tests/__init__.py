"""Declares this module as a package"""

# tests/__init__.py

# This file can be empty or contain initialization code for the package
